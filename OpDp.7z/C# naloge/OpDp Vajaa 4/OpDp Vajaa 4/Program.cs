﻿using System;
class Vaja4
{
    

    static void Main(String[] args){
        preveri(ObrniSt(123) == 321, "Napaka pri zrcaljenju števila!");
        preveri(JePrastevilo(13), "Napaka pri preverjanju praštevila!");
        preveri(PosebnoPrastevilo(13), "Napaka pri preverjanju posebnega praštevila!");

        int st = Convert.ToInt32(Console.ReadLine());
    



        if(st < 1 || st > 1000)
        {
            Console.WriteLine("ERROR");
        }
        else
        {
            Console.WriteLine("Vhod: " + st);
        }
        SteviloDeliteljev(st);


        Console.Write("Delitelji: "); Delitelji(st);
        Console.WriteLine("");

        if (JePrastevilo(st) == true)
        {
            Console.WriteLine("Je praštevilo.");

            if (PosebnoPrastevilo(st))
            {
                Console.WriteLine($"Število {st} je posebno praštevilo (vsota števk je praštevilo).");
            }
            else
            {
                Console.WriteLine($"Število {st} ni posebno praštevilo.");
            }

            if (JePrastevilo(ObrniSt(st)) == true)
            {
                Console.WriteLine($"Po zrcalnem obračanju števila {st}, je dobljeno število "+ObrniSt(st)+" tudi praštevilo.");
            }
            else
            {
                Console.WriteLine($"Po zrcalnem obračanju števila {st}, je dobljeno število " + ObrniSt(st)+" ni praštevilo.");
            }
        }
        else
        {
            Console.WriteLine("Ni praštevilo.");
        }






    }

    private static void Delitelji(int st)
    {
        for (int i = 1; i <= st; i++) {
            if (st % i == 0)
            {
                Console.Write(i+", ");
            }
            
            
        }
    }

    static bool JePrastevilo(int st)
    {

        if (st <= 1) return false; 

        
        for (int i = 2; i * i <= st; i++)
        {
            if (st % i == 0)
                return false;
        }

        return true;
    }
    static int ObrniSt(int st)
    {
        int reverse = 0;

        while (st != 0)
        {
            int ost = st % 10;
            reverse = (reverse * 10) + ost; 
            st /= 10; 
        }

        return reverse;
    }

    static bool PosebnoPrastevilo(int st)
    {
        int vsota = 0;
        int temp = st;

        while (temp != 0)
        {
            vsota += temp % 10;
            temp /= 10;
        }      
        return JePrastevilo(st) && (JePrastevilo(vsota) || vsota == 4);
    }




    static void preveri(bool pogoj, string opozoriloONapaki)
    {
        if (!pogoj)
            Console.WriteLine(opozoriloONapaki);
    }


    static void SteviloDeliteljev(int st)
    {
        int steviloDeliteljev = 0;

        for (int i = 1; i <= st; i++)
        {
            if (st % i == 0)
            {
                steviloDeliteljev++;
            }
        }

        Console.WriteLine($"Število deliteljev: {steviloDeliteljev}");
    }



}

