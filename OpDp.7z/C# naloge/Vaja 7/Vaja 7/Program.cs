﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Vaja7
{
    
    public enum Modifier
    {
        Public,
        Private,
        Protected,
        Internal
    }

    
    public class ClassBuilder
    {
        public string ClassName { get; private set; }
        public Modifier ClassModifier { get; private set; }
        private List<(Modifier Modifier, string Type, string Name)> Variables { get; } = new List<(Modifier, string, string)>();

        public void SetClassName(string name)
        {
            ClassName = name;
        }

        public void SetClassModifier(Modifier modifier)
        {
            ClassModifier = modifier;
        }

        public void AddVariable(Modifier modifier, string type, string name)
        {
            Variables.Add((modifier, type, name));
        }

        public void PrintClassSkeleton()
        {
            Console.WriteLine($"{ClassModifier.ToString().ToLower()} class {ClassName}");
            Console.WriteLine("{");
            foreach (var variable in Variables)
            {
                Console.WriteLine($"    {variable.Modifier.ToString().ToLower()} {variable.Type} {variable.Name};");
            }
            Console.WriteLine("}");
        }

        public void SaveToFile(string fileName)
        {
            string folderPath = AppDomain.CurrentDomain.BaseDirectory; // Pot do trenutnega delovnega imenika
            string fullPath = Path.Combine(folderPath, fileName);

            using (StreamWriter writer = new StreamWriter(fullPath))
            {
                writer.WriteLine($"{ClassModifier.ToString().ToLower()} class {ClassName}");
                writer.WriteLine("{");
                foreach (var variable in Variables)
                {
                    writer.WriteLine($"    {variable.Modifier.ToString().ToLower()} {variable.Type} {variable.Name};");
                }
                writer.WriteLine("}");
            }

            Console.WriteLine($"Class saved to file: {fullPath}");
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            ClassBuilder builder = new ClassBuilder();

            
            Console.WriteLine("Vnesite ime razreda:");
            string name = Console.ReadLine();
            builder.SetClassName(name);

            
            Console.WriteLine("Izberite modifikator:");
            Console.WriteLine("1. Public");
            Console.WriteLine("2. Private");
            Console.WriteLine("3. Protected");
            Console.WriteLine("4. Internal");
            int choice = int.Parse(Console.ReadLine());
            Modifier modifier = (Modifier)(choice - 1);
            builder.SetClassModifier(modifier);

            
            Console.WriteLine("Dodajanje spremenljivk (vnesite 'done' za končanje):");
            while (true)
            {
                Console.WriteLine("Vnesite ime spremenljivke (ali 'done' za končanje):");
                string variableName = Console.ReadLine();
                if (variableName.ToLower() == "done") break;

                Console.WriteLine("Vnesite tip spremenljivke (npr. int, string, double):");
                string variableType = Console.ReadLine();

                Console.WriteLine("Izberite modifikator spremenljivke:");
                Console.WriteLine("1. Public");
                Console.WriteLine("2. Private");
                Console.WriteLine("3. Protected");
                Console.WriteLine("4. Internal");
                int variableChoice = int.Parse(Console.ReadLine());
                Modifier variableModifier = (Modifier)(variableChoice - 1);

                builder.AddVariable(variableModifier, variableType, variableName);
            }

            // 4. Izpis razreda
            Console.WriteLine("\nSkelet razreda:");
            builder.PrintClassSkeleton();

            // 5. Shranjevanje v datoteko
            Console.WriteLine("\nVnesite ime datoteke za shranjevanje (npr. MyClass.cs):");
            string filePath = Console.ReadLine();
            builder.SaveToFile(filePath);
        }
    }
}
