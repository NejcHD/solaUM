﻿using System.IO;
public class VAJA
{
    public static void Main(String[] args)
    {
        Console.WriteLine("Izberi kaj zelis delat- 1 za vpis, 2 za izpis");
        int odlocitev = Convert.ToInt32(Console.ReadLine());
        if (odlocitev == 1)
        {
            Console.WriteLine("Vnesi stevilo:");
            string input;
            do
            {
                input = Console.ReadLine();
                vnos(input);
            } while (input != "Exit");
        }
        else
        {
            Console.WriteLine("Izpisi fila");
            
            izpis();
            
        }
    }

    public static void vnos( string input)
    {
        if (input != "exit")
        {
            int st = int.Parse(input);

            File.AppendAllText("C:\\sola\\C# naloge\\Vaja doma\\text.txt", st.ToString() + ", ");
            Console.WriteLine("Vnoseno");
        }
        else
        {
            Console.WriteLine("Konec");
            
        }
    }
    public static void izpis()
    {
        Console.WriteLine(File.ReadAllText("C:\\sola\\C# naloge\\Vaja doma\\text.txt"));
    }
}

