﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Globalization;
struct Opravilo
{
    public int Id;
    public string Oznaka;
    public string Opis;
    public string Rok;
    public double OdstotekZakljucenosti;

    public Opravilo(int id, string oznaka, string opis, string rok, double odstotekZakljucenosti)
    {
        Id = id;
        Oznaka = oznaka;
        Opis = opis;
        Rok = rok;
        OdstotekZakljucenosti = odstotekZakljucenosti;
    }

    public override string ToString()
    {
        return $"ID: {Id}, Oznaka: {Oznaka}, Opis: {Opis}, Rok: {Rok}, Odstotek zaključenosti: {OdstotekZakljucenosti * 100}%";
    }

}
public class Vaja6
{

    public static void Main(string[] args)
    {
        List<Opravilo> opravila = new List<Opravilo>();
        string vhodnaDatoteka = "C:\\sola\\C# naloge\\Vaja6\\Vhod.txt";
        string izhodnaDatoteka = "C:\\sola\\C# naloge\\Vaja6\\Izhod.txt";

        PreberiIzDatoteke(vhodnaDatoteka, ref opravila);

        while (true)
        {
            Console.WriteLine("\nIzberite operacijo:");
            Console.WriteLine("1. Izpis vseh opravil");
            Console.WriteLine("2. Vnos opravila");
            Console.WriteLine("3. Spreminjanje opravila");
            Console.WriteLine("4. Izbris opravila");
            Console.WriteLine("5. Izračun preostalega časa do zapadlosti");
            Console.WriteLine("6. Urejanje po oznaki");
            Console.WriteLine("7. Urejanje po odstotku zaključenosti");
            Console.WriteLine("8. Shranjevanje v datoteko");
            Console.WriteLine("9. Izhod");

            int izbira = int.Parse(Console.ReadLine());

            switch (izbira)
            {
                case 1:
                    foreach (var opravilo in opravila)
                        Console.WriteLine(opravilo);
                    break;
                case 2:
                    VnosOpravila(opravila);
                    break;
                case 3:
                    SpreminjanjeInVraciloOpravila(ref opravila);
                    break;
                case 4:
                    IzbrisOpravila(opravila);
                    break;
                case 5:
                    PreostaliČas(opravila);
                    break;
                case 6:
                    UrediPoOznaki(opravila);
                    break;
                case 7:
                    UrediPoOdstotku(opravila);
                    break;
                case 8:
                    ShraniVDatoteko(izhodnaDatoteka, opravila);
                    break;
                case 9:
                    return;
                default:
                    Console.WriteLine("Napačna izbira. Poskusite znova.");
                    break;
            }
        }
    }

    static void PreberiIzDatoteke(string pot, ref List<Opravilo> opravilo)
    {
        if (File.Exists(pot))
        {
            String[] vrstice = File.ReadAllLines(pot);  //preberemo vse iz datoteke

            foreach(string vrstica in vrstice)
            {
                String[] deli = vrstica.Split(',');  // razdelimo vrstico na dele
                int id = int.Parse(deli[0].Trim());
                String oznaka = deli[1].Trim();
                String opis = deli[2].Trim();
                String rok = deli[3].Trim();

                double odstotekZakljucnosti = double.Parse(deli[4].Trim(), CultureInfo.InvariantCulture);
                opravilo.Add(new Opravilo(id, oznaka, opis, rok, odstotekZakljucnosti));
            }
        }
        else
        {
            Console.WriteLine($"Datoteka '{pot}' ne obstaja.");
        }
    }

    static void VnosOpravila(List<Opravilo> opravilo)
    {
        int id;

        while (true)
        {
            Console.WriteLine("Vnesite ID opravila (cela številka):");
            string input = Console.ReadLine();

           
            if (int.TryParse(input, out id))
            {
                if (opravilo.Exists(o => o.Id == id))
                {
                    Console.WriteLine("Opravilo z tem ID že obstaja! Poskusite znova.");
                }
                else
                {
                    break; 
                }
            }
            else
            {
                Console.WriteLine("Napaka: Vnesite veljavno celo število.");
            }
        }

        Console.WriteLine("Vnesite oznako opravila:");
        string oznaka = Console.ReadLine();

        Console.WriteLine("Vnesite opis opravila:");
        string opis = Console.ReadLine();

        Console.WriteLine("Vnesite rok (DD/MM/YYYY):");
        string rok = Console.ReadLine();

        double odstotekZakljucenosti;
        while (true)
        {
            Console.WriteLine("Vnesite odstotek zaključenosti (decimalno število med 0 in 100):");
            string odstotekInput = Console.ReadLine();

            // Preverimo, ali je vnos veljavno decimalno število
            if (double.TryParse(odstotekInput, NumberStyles.Float, CultureInfo.InvariantCulture, out odstotekZakljucenosti) &&
                odstotekZakljucenosti >= 0 && odstotekZakljucenosti <= 100)
            {
                break;
            }
            else
            {
                Console.WriteLine("Napaka: Vnesite veljavno decimalno število med 0 in 100.");
            }
        }

        opravilo.Add(new Opravilo(id, oznaka, opis, rok, odstotekZakljucenosti));   //ustvarimo opravilo
        Console.WriteLine("Opravilo je bilo uspešno dodano.");
    }


    static void SpreminjanjeInVraciloOpravila(ref List<Opravilo> opravila)
    {
        Console.WriteLine("Vnesite ID opravila za spremembo:");
        int id = int.Parse(Console.ReadLine());

        // Poiščemo opravilo z določenim ID-jem
        Opravilo opravilo = opravila.Find(o => o.Id == id);

        // Preverimo, ali je bilo opravilo najdeno
        if (opravilo.Id != 0)  
        {
            Console.WriteLine("Vnesite nov opis opravila:");
            opravilo.Opis = Console.ReadLine();

            Console.WriteLine("Vnesite nov rok končanja (DD/MM/YYYY):");
            opravilo.Rok = Console.ReadLine();

            Console.WriteLine("Vnesite nov odstotek zaključenosti:");
            opravilo.OdstotekZakljucenosti = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);

            Console.WriteLine("Opravilo je bilo uspešno spremenjeno.");
        }
        else
        {
            Console.WriteLine("Opravilo z tem ID ne obstaja.");
        }
    }

    static void IzpisInVraciOpravila(List<Opravilo> opravila)
    {
        Console.WriteLine("Vnesite ID opravila za ispit:");
        int id = int.Parse(Console.ReadLine());

        Opravilo opravilo = opravila.Find(o => o.Id == id);

        if (opravilo.Id != 0 || opravilo.Oznaka != null)  // Preverjanje za strukturo (privzete vrednosti)
        {
            Console.WriteLine($"ID: {opravilo.Id}, Oznaka: {opravilo.Oznaka}, Opis: {opravilo.Opis}, Rok: {opravilo.Rok}, Odstotek zaključenosti: {opravilo.OdstotekZakljucenosti}");
        }
        else
        {
            Console.WriteLine($"Opravilo z ID {id} ne obstaja.");
        }
    }

    static void IzpisVsehOpravil(List<Opravilo> opravila)
    {
        if (opravila.Count == 0)
        {
            Console.WriteLine("Seznam opravil je prazen.");
            return;
        }

        Console.WriteLine("Vsa opravila:");
        foreach (var opravilo in opravila)
        {
            Console.WriteLine($"ID: {opravilo.Id}, Oznaka: {opravilo.Oznaka}, Opis: {opravilo.Opis}, Rok: {opravilo.Rok}, Odstotek zaključenosti: {opravilo.OdstotekZakljucenosti}");
        }
    }

    static void ShraniVDatoteko(string pot, List<Opravilo> opravila)
    {
        try
        {
            List<string> vrstice = new List<string>();
            foreach (var opravilo in opravila)
            {
                vrstice.Add(opravilo.ToString());
            }
            File.WriteAllLines(pot, vrstice);
            Console.WriteLine($"Opravila so bila uspešno shranjena v datoteko: {pot}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Prišlo je do napake pri shranjevanju: {ex.Message}");
        }
    }


    static void IzbrisOpravila(List<Opravilo> opravila)
    {
        Console.WriteLine("Vnesite ID ali oznako opravila za izbris:");
        string vnos = Console.ReadLine();

        Opravilo opravilo = opravila.Find(o => o.Id.ToString() == vnos || o.Oznaka == vnos);

        if (opravilo.Id != 0 || opravilo.Oznaka != null)
        {
            opravila.Remove(opravilo);
            Console.WriteLine("Opravilo je bilo uspešno izbrisano.");
        }
        else
        {
            Console.WriteLine("Opravilo z navedenim ID-jem ali oznako ne obstaja.");
        }
    }

    static void PreostaliČas(List<Opravilo> opravila)
    {
       
        Console.WriteLine("Vnesite ID opravila za izračun preostalega časa:");
        string idInput = Console.ReadLine(); 

       
        if (int.TryParse(idInput, out int id))
        {
           
            Opravilo opravilo = opravila.Find(o => o.Id == id);

            
            if (opravilo.Id != 0)
            {
                
                DateTime rok = DateTime.ParseExact(opravilo.Rok, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                
                TimeSpan preostaliCas = rok - DateTime.Now;

                
                if (preostaliCas.Days >= 0)
                {
                    Console.WriteLine($"Preostali čas do zapadlosti: {preostaliCas.Days} dni.");
                }
                else
                {
                    Console.WriteLine("Rok je že potekel.");
                }
            }
            else
            {
                // Če opravilo ni bilo najdeno
                Console.WriteLine("Opravilo z navedenim ID-jem ne obstaja.");
            }
        }
        else
        {
            // Če ID ni številka
            Console.WriteLine("Napaka: Vnesite veljaven ID opravila.");
        }
    }


    static void UrediPoOznaki(List<Opravilo> opravila)
    {
        opravila.Sort((x, y) => x.Oznaka.CompareTo(y.Oznaka));
        Console.WriteLine("Opravila so bila urejena po oznaki:");
        foreach (var opravilo in opravila)
        {
            Console.WriteLine(opravilo);
        }
    }


    static void UrediPoOdstotku(List<Opravilo> opravila)
    {
        opravila.Sort((x, y) => x.OdstotekZakljucenosti.CompareTo(y.OdstotekZakljucenosti));
        Console.WriteLine("Opravila so bila urejena po odstotku zaključnosti:");
        foreach (var opravilo in opravila)
        {
            Console.WriteLine(opravilo);
        }
    }


}



