﻿using System.IO;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Diagnostics;
namespace Ucenje{

    struct Opravilo{
        public int Id;
        public String Oznaka;
        public String Opis;
    }

    public class Vaja1
    {
        private List<Opravilo> opravila = new List<Opravilo>();
        public static void Main(String[] args)
        {

            Vaja1 vaja = new Vaja1();
            Console.WriteLine("1. Preberi opravila");
            Console.WriteLine("2. Vpisi opravilo");


            int izbira = int.Parse(Console.ReadLine());

            switch (izbira)
            {
                case 1:
                    vaja.PreberiIzDatoteke();
                    break;
                case 2:
                    vaja.DodajOpravilo();
                    break;
            }

        }

        public void PreberiIzDatoteke()
        {
            Console.WriteLine(File.ReadAllText("C:\\sola\\C# naloge\\Vaja3.1\\Vhod.txt"));
        }
        public void DodajOpravilo()
        {
            Opravilo novoOpravilo = new Opravilo();
           Console.WriteLine("Vnesi id!");
            {
                if (!int.TryParse(Console.ReadLine(), out novoOpravilo.Id))
                {
                    Console.WriteLine("Neveljaven id");
                }


                Console.WriteLine("Vnesi Oznako!");
                novoOpravilo.Oznaka = (Console.ReadLine());

                Console.WriteLine("Vnesi Opis!");
                novoOpravilo.Opis = (Console.ReadLine());

                foreach (var opravilo in opravila)
                {
                    if (opravilo.Id == novoOpravilo.Id)
                    {
                        Console.WriteLine($"Opravilo z idejom {novoOpravilo.Id} ze obstaja");
                        return;
                    }


                }
                String file = $"{novoOpravilo.Id},{novoOpravilo.Oznaka},{novoOpravilo.Opis}";

                opravila.Add(novoOpravilo);
                Console.WriteLine("Uspesno dodano");
                try
                {
                    File.AppendAllText("C:\\sola\\C# naloge\\Vaja3.1\\Vhod.txt", file + Environment.NewLine);
                }catch (Exception ex){
                    Console.WriteLine("Eroor");
                }



            }

        }


    }
    }