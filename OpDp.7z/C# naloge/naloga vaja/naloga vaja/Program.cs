﻿public class Vaja
{

    public static void Main(string[] args)
    {
        Vaja pretvorba = new Vaja();
       
        
        Console.WriteLine(pretvorba.pretvoriDesetiskoVDvanajstisko(155));
        Console.WriteLine(pretvorba.pretvoriDvanajstiskoVDesetisko("10B"));
    }
    public  string pretvoriDesetiskoVDvanajstisko(int N)
    {
        int temp = 0;
        String nek = "";
        while(N>0)
        {
            temp = N % 12;  //dobimo ostanek
            
            if (temp == 10) { 
                nek = "A" + nek;
            }else if(temp == 11){
                nek = "B" + nek;
            }else{
                nek = temp.ToString() + nek;  //pretvori ostanek v stringe
            }

            N = N / 12; //delimo
            
            

        }

        
        return nek;

    }

    public int pretvoriDvanajstiskoVDesetisko(string Ni)
    {
        int temp = 0;
        int moc = 0;

        // Preberi niz od desne proti levi
        for (int i = Ni.Length - 1; i >= 0; i--)
        {
            char znak = Ni[i];

            int vrednost;

            // Določanje vrednosti za 'A' in 'B'
            if (znak == 'A')
                vrednost = 10;
            else if (znak == 'B')
                vrednost = 11;
            else
                vrednost = znak - '0';  // Pretvori številke '0'–'9' v integer

            // Seštevanje vrednosti pomnoženih z ustrezno potenco 12
            temp += vrednost * (int)Math.Pow(12, moc);

            // Povečaj moč 12
            moc++;
        }

        return temp;  // Vrne desetiško število
    }
}