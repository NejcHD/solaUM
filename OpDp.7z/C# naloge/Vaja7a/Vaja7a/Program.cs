﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Vaja7
{
    public enum Modifier
    {
        Public,
        Private,
        Protected,
        Internal
    }

    public class ClassBuilder
    {
        public string ClassName { get; private set; }
        public Modifier ClassModifier { get; private set; }
        private List<(Modifier Modifier, string Type, string Name)> Variables { get; } = new List<(Modifier, string, string)>();
        private List<(Modifier Modifier, string ReturnType, string MethodName)> Methods { get; } = new List<(Modifier, string, string)>();
        private List<(Modifier Modifier, string Type, string Name, string Value)> Constants { get; } = new List<(Modifier, string, string, string)>();

        public void DoločiImeRazreda(string ime)
        {
            ClassName = ime;
        }

        public void DoločiModifikatorRazreda(Modifier modifier)
        {
            ClassModifier = modifier;
        }

        public void DodajSpremenljivko(Modifier modifier, string type, string name)
        {
            Variables.Add((modifier, type, name));
        }

        public void DodajMetodo(Modifier modifier, string returnType, string methodName)
        {
            Methods.Add((modifier, returnType, methodName));
        }

        public void DodajKonstantno(Modifier modifier, string type, string name, string value)
        {
            Constants.Add((modifier, type, name, value));
        }

        public void UstvariPrazenKonstruktor()
        {
            Console.WriteLine($"    private {ClassName}() {{ }}");
        }

        public void IzpisiSkeletRazreda()
        {
            Console.WriteLine($"{ClassModifier.ToString().ToLower()} class {ClassName}");
            Console.WriteLine("{");
            foreach (var constant in Constants)
            {
                Console.WriteLine($"    {constant.Modifier.ToString().ToLower()} const {constant.Type} {constant.Name} = {constant.Value};");
            }
            foreach (var variable in Variables)
            {
                Console.WriteLine($"    {variable.Modifier.ToString().ToLower()} {variable.Type} {variable.Name};");
            }
            foreach (var method in Methods)
            {
                Console.WriteLine($"    {method.Modifier.ToString().ToLower()} {method.ReturnType} {method.MethodName}() {{ }}");
            }
            Console.WriteLine("}");
        }

        public void ShraniVDatoteko(string fileName)
        {
            string folderPath = AppDomain.CurrentDomain.BaseDirectory;
            string fullPath = Path.Combine(folderPath, fileName);

            using (StreamWriter writer = new StreamWriter(fullPath))
            {
                writer.WriteLine($"{ClassModifier.ToString().ToLower()} class {ClassName}");
                writer.WriteLine("{");
                foreach (var constant in Constants)
                {
                    writer.WriteLine($"    {constant.Modifier.ToString().ToLower()} const {constant.Type} {constant.Name} = {constant.Value};");
                }
                foreach (var variable in Variables)
                {
                    writer.WriteLine($"    {variable.Modifier.ToString().ToLower()} {variable.Type} {variable.Name};");
                }
                foreach (var method in Methods)
                {
                    writer.WriteLine($"    {method.Modifier.ToString().ToLower()} {method.ReturnType} {method.MethodName}() {{ }}");
                }
                writer.WriteLine("}");
            }

            Console.WriteLine($"Class saved to file: {fullPath}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            ClassBuilder builder = new ClassBuilder();
            bool running = true;

            while (running)
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Set class name");
                Console.WriteLine("2. Set class modifier");
                Console.WriteLine("3. Add variable");
                Console.WriteLine("4. Add method");
                Console.WriteLine("5. Add constant");
                Console.WriteLine("6. Generate empty constructor");
                Console.WriteLine("7. Display class skeleton");
                Console.WriteLine("8. Save class to file");
                Console.WriteLine("9. Exit");

                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter class name:");
                        string name = Console.ReadLine();
                        builder.DoločiImeRazreda(name);
                        break;
                    case 2:
                        Console.WriteLine("Choose class modifier:");
                        Console.WriteLine("1. Public");
                        Console.WriteLine("2. Private");
                        Console.WriteLine("3. Protected");
                        Console.WriteLine("4. Internal");
                        int modChoice = int.Parse(Console.ReadLine());
                        Modifier mod = (Modifier)(modChoice - 1);
                        builder.DoločiModifikatorRazreda(mod);
                        break;
                    case 3:
                        Console.WriteLine("Enter variable type:");
                        string varType = Console.ReadLine();
                        Console.WriteLine("Enter variable name:");
                        string varName = Console.ReadLine();
                        Console.WriteLine("Choose variable modifier:");
                        Console.WriteLine("1. Public");
                        Console.WriteLine("2. Private");
                        Console.WriteLine("3. Protected");
                        Console.WriteLine("4. Internal");
                        int varModChoice = int.Parse(Console.ReadLine());
                        Modifier varMod = (Modifier)(varModChoice - 1);
                        builder.DodajSpremenljivko(varMod, varType, varName);
                        break;
                    case 4:
                        Console.WriteLine("Enter method return type:");
                        string returnType = Console.ReadLine();
                        Console.WriteLine("Enter method name:");
                        string methodName = Console.ReadLine();
                        Console.WriteLine("Choose method modifier:");
                        Console.WriteLine("1. Public");
                        Console.WriteLine("2. Private");
                        Console.WriteLine("3. Protected");
                        Console.WriteLine("4. Internal");
                        int methodModChoice = int.Parse(Console.ReadLine());
                        Modifier methodMod = (Modifier)(methodModChoice - 1);
                        builder.DodajMetodo(methodMod, returnType, methodName);
                        break;
                    case 5:
                        Console.WriteLine("Enter constant type:");
                        string constType = Console.ReadLine();
                        Console.WriteLine("Enter constant name:");
                        string constName = Console.ReadLine();
                        Console.WriteLine("Enter constant value:");
                        string constValue = Console.ReadLine();
                        Console.WriteLine("Choose constant modifier:");
                        Console.WriteLine("1. Public");
                        Console.WriteLine("2. Private");
                        Console.WriteLine("3. Protected");
                        Console.WriteLine("4. Internal");
                        int constModChoice = int.Parse(Console.ReadLine());
                        Modifier constMod = (Modifier)(constModChoice - 1);
                        builder.DodajKonstantno(constMod, constType, constName, constValue);
                        break;
                    case 6:
                        builder.UstvariPrazenKonstruktor();
                        break;
                    case 7:
                        builder.IzpisiSkeletRazreda();
                        break;
                    case 8:
                        Console.WriteLine("Enter file name to save (e.g., MyClass.cs):");
                        string filePath = Console.ReadLine();
                        builder.ShraniVDatoteko(filePath);
                        break;
                    case 9:
                        running = false;
                        break;
                    default:
                        Console.WriteLine("Invalid choice, please try again.");
                        break;
                }
            }
        }
    }
}
