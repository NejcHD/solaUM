﻿

using System;

public class Naloga3
{
    public static void Main(string[] args)
    {
        while (true)
        {

            Console.WriteLine("Prosim vnesite menjalno izbiro (1 -  EUR v GBP, 2 - GBP v EUR, 0 - prekinitev programa");
            int odlocitev = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(odlocitev);
            double znesek;

            if (odlocitev == 0)
            {
                Console.WriteLine("NAPAKA!!");
                return;
            }
            else if (odlocitev == 1)
            {
                Console.WriteLine("Prosim vnesite EUR za menajvo: ");
                znesek = Math.Round(Convert.ToDouble(Console.ReadLine()), 2);
                EURvGBP(znesek);
            }
            else
            {
                Console.WriteLine("Prosim vnesite EUR za menajvo: ");
                znesek = Math.Round(Convert.ToDouble(Console.ReadLine()), 2);
                GBPvEUR(znesek);
            }

            Console.WriteLine("Ali želite opraviti ponovno menjavo? (D za DA, N za NE)");
            string odgovor = Console.ReadLine();

            if (odgovor == "N")
            {
                Console.WriteLine("Program je zaključen.");
                return;
            }


            // 1EUR = 0.83   1GBP = 1.2

            // bankovci GBP 100, 50 , 20 , 10, 10, 5 , 1   centi:  50, 20, 10, 5, 2, 1, 0.5
        }
    }
    static void EURvGBP(double znesek)
    {
        double stevilo = znesek * 0.83;
        Console.WriteLine("Za " + znesek + " EUR se izplača " + Math.Round(stevilo, 2) + " GBP");



        int ban = 0;
        double[] bankovci = { 100, 50, 20, 10, 5, 1, 0.50, 0.20, 0.10, 0.05, 0.02, 0.01 };


        foreach (double i in bankovci)
        {
            ban = (int)(stevilo / i);
            Console.WriteLine(i + " GBP: " + ban);
            stevilo = stevilo % i;
            ban = 0;
        }
    }

    // bankovci EUR  200, 100, 50, 20, 10 ,5   ter kovnaci: 50, 20, 10 , 5, 2, 1 , 
    static void GBPvEUR(double znesek)
    {
        double stevilo = znesek * 1.2;
        Console.WriteLine("Za " + znesek + " GBP se izplača " + Math.Round(stevilo, 2)+" EUR");
        int ban = 0;
        double[] bankovci = { 200, 100, 50, 20, 10, 5, 0.50, 0.20, 0.10, 0.05, 0.01 };


        foreach (double i in bankovci)
        {
            ban = (int)(stevilo / i);
            Console.WriteLine(i + " EUR: " + ban);
            stevilo = stevilo % i;
            ban = 0;
        }



    }

}
