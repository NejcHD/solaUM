﻿namespace lolek
{
    class Kms
    {
        public static void Main(String[] args)
        {
            Human human = new Human();
            human.name = "fag";
            human.age = 11;
            human.height = 177;
            human.statistic();

            Human human1 = new Human();
            human1.statistic1("lolek", 17, 188);
        }
    }
    class Human
    {
        public string name;
        public int age;
        public int height;
        public void sleep()
        {
            Console.WriteLine($"Human {name} is sleeping");
        }
        public void statistic()
        {
            Console.WriteLine($"Human {name} {age} {height}");
        }
        public void statistic1(string name, int age, int height)
        {
            Console.WriteLine($"Human {name} {age} {height}");
        }

    }
}