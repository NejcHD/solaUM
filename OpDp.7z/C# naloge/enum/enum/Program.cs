﻿using System;
using System.Runtime.InteropServices;
namespace vaja
{

    enum Pogon
    {
        fwd,
        rwd,
        awd
    }
    struct Avto
    {
         public string ime { get; set; }
        public Pogon pogon { get; set; }

        public void izpisAvta()
        {
            Console.WriteLine($"Ime avta: {ime}, Tip pogona: {pogon}");
        }
    }
    class Program {
        public static void Main(String[] args)
        {

            Avto avto1 = new Avto();

            Console.WriteLine("Vnesi ime avta.");
            avto1.ime = Console.ReadLine();

            Console.WriteLine("Izberite tip pogona:");
            Console.WriteLine("0 - FWD (Front-Wheel Drive)");
            Console.WriteLine("1 - RWD (Rear-Wheel Drive)");
            Console.WriteLine("2 - AWD (All-Wheel Drive)");

            int izbor;
            while (!int.TryParse(Console.ReadLine(), out izbor) || izbor < 0 || izbor > 2)
            {
                Console.WriteLine("Napaka: Izberite veljavno številko (0, 1, ali 2).");
            }
            avto1.pogon = (Pogon)izbor;

            // Display the car details
            Console.WriteLine("\nVneseni podatki:");
            avto1.izpisAvta();
        }
    }
}