﻿using System;

public class Vaja5
{
    public static void Main(String[] args)
    {
        Console.WriteLine("Vpisi Desetisko stevilo za pretvorbo v Dvanajstisko:");
        int deseti = Convert.ToInt32(Console.ReadLine());
        string dvanajstisko = pretvoriDesetiskoVDvanajstisko(deseti);
        Console.WriteLine("Rezultat v Dvanajstisko: " + dvanajstisko);
        preveri(dvanajstisko == "A3", "Test pretvoriDesetiskoVDvanajstisko");

        Console.WriteLine("Vpisi Dvanajstisko stevilo za pretvorbo v Desetisko:");
        string dvanajstiskoInput = Console.ReadLine();
        int desetiRezultat = pretvoriDvanajstiskoVDesetisko(dvanajstiskoInput);
        Console.WriteLine("Rezultat v Desetisko: " + desetiRezultat);
        preveri(desetiRezultat == 123, "Test pretvoriDvanajstiskoVDesetisko");

        Console.WriteLine("Vpisi Desetisko stevilo za pretvorbo v Dvanajstisko rekurzivno:");
        deseti = Convert.ToInt32(Console.ReadLine());
        dvanajstisko = pretvoriDesetiskoVDvanajstiskoRekurzivno(deseti);
        Console.WriteLine("Rezultat v Dvanajstisko (rekurzivno): " + dvanajstisko);
        preveri(dvanajstisko == "A3", "Test pretvoriDesetiskoVDvanajstiskoRekurzivno");

        Console.WriteLine("Vpisi Dvanajstisko stevilo za pretvorbo v Desetisko rekurzivno:");
        dvanajstiskoInput = Console.ReadLine();
        desetiRezultat = pretvoriDvanajstiskoVDesetiskoRekurzivno(dvanajstiskoInput);
        Console.WriteLine("Rezultat v Desetisko (rekurzivno): " + desetiRezultat);
        preveri(desetiRezultat == 123, "Test pretvoriDvanajstiskoVDesetiskoRekurzivno");
    }

    public static string pretvoriDesetiskoVDvanajstisko(int deseti)
    {
        int ost;
        string kon = "";

        if (deseti == 0) return "0"; 

        do
        {
            ost = deseti % 12;
            if (ost < 10)
            {
                kon = ost.ToString() + kon;
            }
            else
            {
                kon = (ost == 10 ? "A" : "B") + kon;
            }
            deseti /= 12;
        } while (deseti > 0);

        return kon;
    }

    public static int pretvoriDvanajstiskoVDesetisko(string dva)
    {
        int rezultat = 0;

        for (int i = 0; i < dva.Length; i++)
        {
            char znak = dva[i];
            int stevka;

            if (Char.IsDigit(znak))
            {
                stevka = Convert.ToInt32(znak.ToString());
            }
            else
            {
                stevka = Char.ToUpper(znak) - 'A' + 10;
            }

            int potenca = dva.Length - i - 1;
            rezultat += stevka * (int)Math.Pow(12, potenca);
        }

        return rezultat;
    }

    public static string pretvoriDesetiskoVDvanajstiskoRekurzivno(int deseti)
    {
        if (deseti == 0) return "0"; 

        int ost = deseti % 12;
        string kon = ost < 10 ? ost.ToString() : (ost == 10 ? "A" : "B");

        if (deseti / 12 == 0) return kon; 

        return pretvoriDesetiskoVDvanajstiskoRekurzivno(deseti / 12) + kon;
    }

    public static int pretvoriDvanajstiskoVDesetiskoRekurzivno(string dva)
    {
        if (dva.Length == 0) return 0; 

        char znak = dva[0];
        int stevka;

        if (Char.IsDigit(znak))
        {
            stevka = Convert.ToInt32(znak.ToString());
        }
        else
        {
            stevka = Char.ToUpper(znak) - 'A' + 10;
        }

        return stevka * (int)Math.Pow(12, dva.Length - 1) + pretvoriDvanajstiskoVDesetiskoRekurzivno(dva.Substring(1));
    }

    public static void preveri(bool pogoj, string testIme)
    {
        if (pogoj)
        {
            Console.WriteLine(testIme + " uspešen!");
        }
        else
        {
            Console.WriteLine(testIme + " neuspešen.");
        }
    }
}
